# final-active

css 的內建動畫

animation-duration: 在多久時間完成動畫

animation-fill-mode: 將保留最後一個 frame 的動畫

[final-prob.md](https://final-project-409631503.vercel.app/)

![](https://i.imgur.com/5ZxgO5o.png)
